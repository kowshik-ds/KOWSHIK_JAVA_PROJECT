# Library Management System (Java)

A menu-driven console application for managing books, library members, book issues, returns, availability, and late-return fines.

## Features
- Add books and register student/faculty members
- Issue and return books
- Tracks stock availability
- Prevents issuing unavailable books and duplicate active loans of the same title to one member
- Student borrowing limit: 3 books; faculty limit: 6 books
- Calculates late fines (Rs. 2/day, capped at the book price; faculty receive a 50% reduction)
- Validates user input and displays issue/return receipts

## Requirements
- Java 11 or newer

## Run
Open a terminal in the project folder and run:

```bash
javac -d out src/LibraryManagementSystem.java
java -cp out LibraryManagementSystem
```

## Project structure
```text
LibraryManagementSystem/
├── src/
│   └── LibraryManagementSystem.java
├── README.md
└── .gitignore
```

## Notes
This is a clean, GitHub-ready implementation based on the Library Management System assignment brief. It is organized as a single Java source file to make compiling and running straightforward.
