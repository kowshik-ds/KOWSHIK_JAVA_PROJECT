import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * Library Management System - Java 11+
 * Menu-driven console application for managing books, members, loans and fines.
 */
public class LibraryManagementSystem {
    static class Book {
        int id, total, available;
        String title, author;
        double price;
        Book(int id, String title, String author, int total, double price) {
            this.id=id; this.title=title; this.author=author;
            this.total=total; this.available=total; this.price=price;
        }
    }
    static class Member {
        int id; String name; boolean faculty;
        Member(int id, String name, boolean faculty) {
            this.id=id; this.name=name; this.faculty=faculty;
        }
        int limit() { return faculty ? 6 : 3; }
    }
    static class Loan {
        int id; Member member; Book book; LocalDate issueDate, dueDate;
        boolean returned=false;
        Loan(int id, Member m, Book b, LocalDate date) {
            this.id=id; member=m; book=b; issueDate=date;
            dueDate=date.plusDays(facultyDays(m) + 14);
        }
        static int facultyDays(Member m) { return m.faculty ? 14 : 0; }
    }

    private final Scanner sc = new Scanner(System.in);
    private final List<Book> books = new ArrayList<>();
    private final List<Member> members = new ArrayList<>();
    private final List<Loan> loans = new ArrayList<>();
    private int nextBook=1, nextMember=1, nextLoan=1;

    public static void main(String[] args) { new LibraryManagementSystem().run(); }

    private void run() {
        System.out.println("Welcome to Library Management System");
        boolean running=true;
        while (running) {
            System.out.println("\n===== LIBRARY MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Book\n2. Register Member\n3. Issue Book");
            System.out.println("4. Return Book\n5. Display Books & Availability\n6. Exit");
            int choice=readInt("Enter choice (1-6): ",1,6);
            try {
                switch(choice) {
                    case 1: addBook(); break;
                    case 2: registerMember(); break;
                    case 3: issueBook(); break;
                    case 4: returnBook(); break;
                    case 5: displayBooks(); break;
                    case 6: running=false; System.out.println("Thank you. Goodbye!"); break;
                }
            } catch (IllegalArgumentException ex) {
                System.out.println("[ERROR] "+ex.getMessage());
            }
        }
        sc.close();
    }

    private void addBook() {
        String title=readText("Book title: ");
        String author=readText("Author name: ");
        int copies=readInt("Number of copies (1-50): ",1,50);
        double price=readDouble("Book price (Rs.): ",0.01,100000);
        for(Book b:books)
            if(b.title.equalsIgnoreCase(title) && b.author.equalsIgnoreCase(author))
                throw new IllegalArgumentException("This book is already in the catalogue.");
        Book b=new Book(nextBook++,title,author,copies,price); books.add(b);
        System.out.printf("[OK] Added B%03d | %s | %d copies | Rs.%.2f%n",b.id,b.title,b.total,b.price);
    }

    private void registerMember() {
        String name=readText("Member name: ");
        int type=readInt("Type (1=Student, 2=Faculty): ",1,2);
        Member m=new Member(nextMember++,name,type==2); members.add(m);
        System.out.printf("[OK] Registered M%03d | %s | %s | max %d books%n",
                m.id,m.name,m.faculty?"Faculty":"Student",m.limit());
    }

    private void issueBook() {
        if(books.isEmpty() || members.isEmpty())
            throw new IllegalArgumentException("Add a book and register a member first.");
        displayMembers();
        int mid=readInt("Member ID number: ",1,Integer.MAX_VALUE);
        Member m=findMember(mid);
        int bid=readInt("Book ID number: ",1,Integer.MAX_VALUE);
        Book b=findBook(bid);
        if(b.available<=0) throw new IllegalArgumentException("No copy is currently available.");
        long active=loans.stream().filter(l->l.member==m && !l.returned).count();
        if(active>=m.limit()) throw new IllegalArgumentException("Member borrowing limit reached.");
        if(loans.stream().anyMatch(l->l.member==m && l.book==b && !l.returned))
            throw new IllegalArgumentException("Member already holds this title.");
        LocalDate date=readDate("Issue date (dd-MM-yyyy, blank=today): ");
        Loan l=new Loan(nextLoan++,m,b,date); loans.add(l); b.available--;
        System.out.println("\n============= BOOK ISSUE SLIP =============");
        System.out.printf("Loan ID: LN%03d%nMember: %s (M%03d)%nBook: %s (B%03d)%n",
                l.id,m.name,m.id,b.title,b.id);
        System.out.println("Issued: "+l.issueDate+" | Due: "+l.dueDate);
        System.out.printf("Shelf availability: %d of %d copies%n",b.available,b.total);
    }

    private void returnBook() {
        List<Loan> active=new ArrayList<>();
        for(Loan l:loans) if(!l.returned) active.add(l);
        if(active.isEmpty()) throw new IllegalArgumentException("There are no books currently on loan.");
        System.out.println("Active loans:");
        for(Loan l:active) System.out.printf("LN%03d | %s | B%03d %s | due %s%n",
                l.id,l.member.name,l.book.id,l.book.title,l.dueDate);
        int id=readInt("Loan ID number: ",1,Integer.MAX_VALUE);
        Loan l=loans.stream().filter(x->x.id==id && !x.returned).findFirst()
                .orElseThrow(()->new IllegalArgumentException("Active loan not found."));
        LocalDate date=readDate("Return date (dd-MM-yyyy, blank=today): ");
        if(date.isBefore(l.issueDate)) throw new IllegalArgumentException("Return date cannot be before issue date.");
        long late=Math.max(0,ChronoUnit.DAYS.between(l.dueDate,date));
        double rate=2.0;
        double fine=Math.min(late*rate,l.book.price)*(l.member.faculty?0.5:1.0);
        l.returned=true; l.book.available++;
        System.out.println("\n========= RETURN & FINE RECEIPT =========");
        System.out.printf("Receipt: FN%03d%nBook: %s%nMember: %s%nDue date: %s%nReturned: %s%n",
                l.id,l.book.title,l.member.name,l.dueDate,date);
        System.out.println("Days late: "+late);
        System.out.printf("Fine payable: Rs.%.2f%n",fine);
        System.out.printf("Shelf copies: %d of %d%n",l.book.available,l.book.total);
    }

    private void displayBooks() {
        System.out.println("\n---------------- BOOKS & AVAILABILITY ----------------");
        if(books.isEmpty()) { System.out.println("No books added yet."); return; }
        System.out.printf("%-7s %-28s %-22s %-10s %-12s%n","Book ID","Title","Author","Available","Price");
        for(Book b:books)
            System.out.printf("B%-6d %-28s %-22s %d/%d        Rs.%.2f%n",
                    b.id,fit(b.title,28),fit(b.author,22),b.available,b.total,b.price);
    }
    private void displayMembers() {
        System.out.println("Registered members:");
        for(Member m:members)
            System.out.printf("M%03d | %s | %s | limit %d%n",m.id,m.name,m.faculty?"Faculty":"Student",m.limit());
    }
    private Book findBook(int id) {
        return books.stream().filter(b->b.id==id).findFirst()
                .orElseThrow(()->new IllegalArgumentException("Book not found."));
    }
    private Member findMember(int id) {
        return members.stream().filter(m->m.id==id).findFirst()
                .orElseThrow(()->new IllegalArgumentException("Member not found."));
    }
    private int readInt(String prompt,int min,int max) {
        while(true) {
            System.out.print(prompt); String s=sc.nextLine().trim();
            try { int n=Integer.parseInt(s); if(n>=min && n<=max)return n; }
            catch(NumberFormatException ignored) {}
            System.out.println("Enter a valid number in the range "+min+"-"+max+".");
        }
    }
    private double readDouble(String prompt,double min,double max) {
        while(true) {
            System.out.print(prompt); String s=sc.nextLine().trim();
            try { double n=Double.parseDouble(s); if(Double.isFinite(n)&&n>=min&&n<=max)return n; }
            catch(NumberFormatException ignored) {}
            System.out.println("Enter a valid amount between "+min+" and "+max+".");
        }
    }
    private String readText(String prompt) {
        while(true) {
            System.out.print(prompt); String s=sc.nextLine().trim();
            if(!s.isEmpty() && s.length()<=80)return s;
            System.out.println("Input cannot be empty or longer than 80 characters.");
        }
    }
    private LocalDate readDate(String prompt) {
        while(true) {
            System.out.print(prompt); String s=sc.nextLine().trim();
            if(s.isEmpty()) return LocalDate.now();
            try { return LocalDate.parse(s,java.time.format.DateTimeFormatter.ofPattern("dd-MM-uuuu")); }
            catch(Exception e) { System.out.println("Use date format dd-MM-yyyy."); }
        }
    }
    private String fit(String s,int width) { return s.length()<=width?s:s.substring(0,width-2)+".."; }
}
